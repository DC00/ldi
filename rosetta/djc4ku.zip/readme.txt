Daniel Coo (djc4ku)

A 24 hours extension was requested and granted. Professor Weimer asked me to reference the
email in the readme file.

The current time is 1:32:45. I spent more than 15 hours on this assignment and I feel pretty
tired and discouraged. But today is a new day.

I started with Python so that I could follow the same procedure for OCaml and Cool. I had a very
minor error that I missed while testing which I fixed after PA1C. I stored my implicit graph in a
dictionary.

I had never tried learning two languages in two weeks. I wanted to be sure I learned the syntax 
well, so I read the reference manual for Cool and the online docs for OCaml. After Python I started  
OCaml. Learning the basics of functional programming was tricky, and I had a hard time wrapping my 
head around even basic examples. After going to office hours it slowly started to click, and I was able
to design my program in a more efficient way. I stored my implicit graph in a Hashtbl which mapped 
each node to a List of its incoming nodes. I found iterating over Hashtbls and Lists straightforward
because each had their own iterator. I wrote my OCaml program in a pretty imperative fashion, so in
the future I want to take a more modular approach.

Cool is probably the most verbose language I have ever seen. I watched each of the example videos
on Cool twice, and I was still having trouble seeing how the classes linked together. I stored my
implicit graph in a List of Lists, because Martin said so. I made a new GraphNode class that has
another pointer to a list in addition to its "key" and "value."





