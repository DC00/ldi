import sys
L = []  # list of sorted elements
S = [] # set of all nodes w/ no incoming edges
graph = []  # graph of tuples

lines = sys.__stdin__.readlines()
lines = [ x.strip() for x in lines ]

# for x in lines:
#     print(x)

it = iter(lines)
edges = zip(it, it)

# for (a,b) in edges:
#    print("edge is: >>%s -> %s<<" % (a,b))

# vertices = [ a for (a,b) in edges ] + [ b for (a,b) in edges ])

vertices = set()
for (a,b) in edges:
    vertices.add(a)
    vertices.add(b)

graph = {}

# print("Check vertices")
# for v in vertices:
#     print(v)

for v in vertices:
    graph.setdefault(v, [])

for (a,b) in edges:
    graph[a].append(b)

def print_graph(graph):
    print("Current Graph")
    for k in graph:
        print("%s" % (k)),
        print(graph[k])

def get_nodes_to_remove(graph):
    nodes_to_remove = []
    for key in graph:
        if (len(graph[key]) == 0):
            nodes_to_remove.append(key)
    return sorted(nodes_to_remove)

# print_graph(graph)

L = [] # List containing sorted elements
S = get_nodes_to_remove(graph) # Set of all nodes with no incoming edges

# print("Check get_nodes_to_remove")
# print(S)

# print("Kahn's")
while len(S) > 0:
    n = S.pop(0)
    # print("Node n=%s" %(n))
    L.append(n)
    # print("L="),
    # print(L)

    for key_node in graph:
        if n in graph[key_node]:
            # print("%s is in graph[%s]" % (n, key_node))
            graph[key_node].remove(n)
            # print("Removed %s from graph[%s]. graph[%s]=" % (n, key_node, key_node))
            # print_graph(graph)
            if len(graph[key_node]) == 0:
                # print("graph[%s] is now empty. inserting %s into S" % (key_node, key_node))
                S.append(key_node)
                S = sorted(S)
                # print("S="),
                # print(S)


for key in graph:
    if len(graph[key]) > 0:
        print("cycle")
        sys.exit()
for elt in L:
    print(elt)

# From Wikipedia
# while S is non-empty do
#     remove a node n from S
#     add n to tail of L
#     for each node m with an edge e from n to m do
#         remove edge e from the graph
#         if m has no other incoming edges then
#             insert m into S
# if graph has edges then
#     return error (graph has at least one cycle)
# else 
#     return L (a topologically sorted order)


        




       













